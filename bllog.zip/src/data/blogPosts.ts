export interface BlogPost {
  slug: string;
  title: string;
  date: string;
  readTime: string;
  tags: string[];
  component: string;
}

export const blogPosts: BlogPost[] = [
  {
    slug: 'upsc-nra-vulnerabilities',
    title: 'UPSC NRA Candidate Portal — Multiple Critical & High-Severity Vulnerabilities',
    date: 'June 14, 2026',
    readTime: '12 min read',
    tags: ['Critical Severity', 'Responsible Disclosure', 'CERT-In Acknowledged', 'Fixed & Patched'],
    component: 'UPSCPost',
  },
];
